# Change log

This project adheres to [Semantic Versioning](http://semver.org/).  
See all notable changes on [Releases](https://github.com/gaearon/redux-devtools-log-monitor/releases) page.
