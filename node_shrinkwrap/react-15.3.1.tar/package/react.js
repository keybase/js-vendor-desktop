'use strict';

module.exports = require('./lib/React');
