# Changelog

See the [upgrade guides][1].


[1]: https://github.com/ramda/ramda/issues?q=label%3A%22upgrade+guide%22
