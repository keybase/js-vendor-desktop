var _arrayOf = require('./internal/_arrayOf');
var _curry1 = require('./internal/_curry1');
var converge = require('./converge');


/**
 * juxt applies a list of functions to a list of values.
 *
 * @func
 * @memberOf R
 * @since v0.19.0
 * @category Function
 * @sig [(a, b, ..., m) -> n] -> ((a, b, ..., m) -> [n])
 * @param {Array} fns An array of functions
 * @return {Function} A function that returns a list of values after applying each of the original `fns` to its parameters.
 * @see R.applySpec
 * @example
 *
 *      var range = R.juxt([Math.min, Math.max]);
 *      range(3, 4, 9, -3); //=> [-3, 9]
 */
module.exports = _curry1(function juxt(fns) {
  return converge(_arrayOf, fns);
});
