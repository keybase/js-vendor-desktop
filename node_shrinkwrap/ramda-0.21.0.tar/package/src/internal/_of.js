module.exports = function _of(x) { return [x]; };
