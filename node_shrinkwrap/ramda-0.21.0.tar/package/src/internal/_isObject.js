module.exports = function _isObject(x) {
  return Object.prototype.toString.call(x) === '[object Object]';
};
