module.exports = function _arrayOf() {
  return Array.prototype.slice.call(arguments);
};
