throw new Error("The node API for `babel` has been moved to `babel-core`.");
