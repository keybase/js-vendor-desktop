module.exports = function() {
	this.cacheable();
	return "// empty (null-loader)";
};
module.exports.pitch = function() {
	this.cacheable();
	return "// empty (null-loader)";
};