throw new Error('The fbjs package should never be required without a full path');
