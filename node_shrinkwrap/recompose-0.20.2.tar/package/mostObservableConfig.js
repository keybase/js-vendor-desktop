'use strict';

exports.__esModule = true;

var _most = require('most');

var _most2 = _interopRequireDefault(_most);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var config = {
  fromESObservable: _most2.default.from
};

exports.default = config;