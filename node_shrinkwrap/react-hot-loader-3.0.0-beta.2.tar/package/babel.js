module.exports = require('./lib/babel');
