var dashboard = require('./dashboard/index.js');

module.exports = dashboard;