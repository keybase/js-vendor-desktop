'use strict'

require('../index')
