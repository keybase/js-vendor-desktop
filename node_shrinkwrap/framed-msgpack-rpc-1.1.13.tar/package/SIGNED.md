##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Comment: GPGTools - https://gpgtools.org

iQIcBAABCgAGBQJV2n2dAAoJEGBSsq0xpmMcsc4QAKM3m4gFO4y8FZNtVPtODdGa
Nos8H1m0HF+yclxga1/I+CCS+Sd4/Fpkk40TuWOuJres3dpAgsSC/d5G9ZDkWers
LQwdp8EjCvKiiZkd6GMmMhf41GVpYU3lzG3fx5e04gRai6of428kzn+sl/Tp+X9q
GwmVTGsDZPFWr9iEVMVqJqtiCYQjEhtyYTRq5mTge492NSMEyeFddUiV3PB9l2N1
Ss61MqzEk6rNQInDanzKzNqjhA+oXDgky9ki10oqTPCzbG43xJp+MHF7Wi3zKZiH
E8AK2BTgsbND+VsbVfGV9A8jXoJyl3SVdoJuALSIQFaDiT9r8BqVwMbPjWbfuKJD
+VO9br1bnfraUSzYe9PgnkEsIi2vCQZdKGnSGQCTYCB60vadmAD5RCeo5IIk/Zm5
m5jtwA+yhEkDzG70F060me8FBNK3TjOTDhZJgWVXbRlfArpyTuTGMMzrF2pAxv2G
gVXDSGqYPMCop5DsoNqrrf/GDdlvMF80bYlBkTN3yEFkdkNhy8FoWBD/b5cBfz9e
1ZILGdh6WKg1NVAzYfqS0FUmXLkn3TuYnRi5SbmIlKdYhyTNmzRlp0elZXAt9WMd
RSrQbYi0xshp1arxX+kfAccHL0kaPnCrp17C/oiurHQPnTo8JHYCvKlf+FsLT1oS
n4AZPiCTexD0LMs+WdTK
=AuMk
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size   exec  file                          contents                                                        
             ./                                                                                            
31             .gitignore                  c04ace3e706338d02c8c851fa1ecf6f3e6239bf6198a0573c182e4e5350c8d33
346            CHANGELOG.md                139e2c7f703bdfa8a097811c5e4b96a72e2000a60f84d49e6f2a2fc5d772772b
1739           Cakefile                    bedb8b17ae1990ac8d999301444a7b6404d50c9dc8324ace29e9ff83ea1b6c03
1062           LICENSE                     9c750e7ffa7dea995d1217e044766daaf99a9ea2db7141b06e264ea398f4c661
21426          README.md                   2000659c6bd32a3c5a6463ea90a409ec5d96ba020d7e9707d50cfcb909051f4b
               lib/                                                                                        
1859             client.js                 3c4ab6f17ab48d9434469d6c3737e984fa8d622af3726aa6bcbb2f24004d7318
5010             debug.js                  1f4538f9871585fe7976c1dd9ecd642a76c395e05ae1bc782a8324404c47dc01
9852             dispatch.js               20cf9865b4f25e5b394143bb3ed37d8c7e2e47c7d9cf06d92729be02bedcfd73
340              errors.js                 e7dc76d9935ef9ef065ca574c9d3616a0ddfdf84f4d2e49aec6f8459cdfba91f
116              iced.js                   ffebf41c56431989ff6c2d660712d5131dbd0a18005827b0ece9f91781592bc6
1132             list.js                   4ddf31674a7a505cb7dca5dc6e998f42eae6bd0b981dc3d1af140698c8e850de
9217             listener.js               4aafc02353e700e8b0fd20c44415fccf1307cfab52b4178df42242417ea7fccd
3231             lock.js                   94acbde2706e02d9dc70acbaa53acfac9eb82bb67b5ed447136ea7f439daeaa8
2764             log.js                    b0a589077edef303ad773685f562287d324f7e065b27be1a527b9081e219b0de
1416             main.js                   25db3a06af47781d8a833919ce30fd4e6cfeea4490c8746a5a7e04fe9481d41b
1112             pack.js                   1c910ab878bba82822c50048cb1ec7e60024bacadf319a9abdaba6394756ffa3
4563             packetizer.js             3e72451639ab0d65e6135e9fdf00d1c37087e951f3b3d96a9b453c88be507ea9
1927             ring.js                   390f9c8dc20151fc9125ec2715aa576c82939a4377a71eddda8827b9f97b4dc7
4485             server.js                 b4bb6d1298a0a5e2d818fd4d26e1f67f941e20fd07a7f5c47909efc218171ddb
984              timer.js                  ab793c0cfabd0e6e602f7657cc17704a7388b57318a4b233a6bc928376a5a437
23133            transport.js              8782c7b35cb579ebd86dc994811943a0de780f7d32710d709b5ceca2571231b7
26               version.js                bff3e2cbc063a0e7c532853faf44abf18b2923fa2e2580be45d425b86163a99f
795            package.json                1f301c4fe542cd51303fbb710c5235191670b23ce67c10ba87409bb3a963c8e7
               src/                                                                                        
714              client.iced               6640bbae283ba92516da749894b7740dc6e10db9af48289282e59da045b1498e
4560             debug.iced                7b2b81b8dae1729ba3d29de7dfac2960d285b7adc7359c4ccf2556bf12b6f70f
5444             dispatch.iced             62606eae4bd18de5cfb58e20a996b8bcb01d4ee482612a2cc164cc7abc25870c
292              errors.iced               9f1ea8d90878bda4d6731f6515c2e8dad362a525affee5016c18bea33c3c195b
43               iced.iced                 cb4f24fdfd66de1cbb8c2b041ca76637a673d256c4629b16c1cb1de0675fb398
947              list.iced                 2b0a49c5aaef4b5f1df984e6350167579cdb161bb4da172cc8b1ad7e510ae75c
4355             listener.iced             ce4712496eebcca2d2d36f17f12efec48b9dc88754429d34bc31d40cc83624ba
1151             lock.iced                 85141295f022a70d8922fad40a5dba1df877b1bb0ca973c4d87d84f66f82ba49
2062             log.iced                  a71934a2b7dec883f077efb8b8fb9e8649fb7581a1a48895b603361343fd5bcd
1327             main.iced                 ecc68bc4ba976cf5b6e806281762e5a25b07090e26b5a54ae94d9656fc4e6922
835              pack.iced                 3ca794db9f89a1d924731c558a9a6e7018c2cd529c5eee6dfb7b098e89be2a7c
4392             packetizer.iced           aa17f8a495043e87b0c3167aeba218b3e5325c77f85dd4130bec3e55c358ae57
1716             ring.iced                 c4fd1a947c1e5330f2a4b6f01f2f8294b84f2117d7841a20d8335de40b973817
3869             server.iced               0fd58cb64617b3068bd6c05d7874eff1190f0f28be345150eea03f9c8b4a471b
469              timer.iced                09837c5f3bdbd4697416fc78f27fb356d602087f9e8760dccd524f9513d3e72c
12689            transport.iced            3bc91901497c8712e9422792e11be3f190db0bb7280480c8e88328758e718a1e
177              version.iced              9ad6d080a3707b15647d707eadab9c0c2397e7c5cf5ad2f6f4eafc0f9327cf1a
               test/                                                                                       
5928             all.iced                  c12477586abfdd047a21466af1f831415210fe52a5dcb395f4a428450ba1ca38
                 support/                                                                                  
97                 jenky_server.js         19e4d06efb8e06b97fb026e07d7308aa9d49141aa0754a250603026e5b760ea7
649                jenky_server_main.iced  9ac51b1faff05c1fd34d06a5e61eac5aff98a31f7463311f089e2309df003863
878              test1.iced                eed561231cb0835168c0ed2c050b6fd831cd14742614e969f206ce58676d716e
1444             test10.iced               8c04ac7bc4e8badb25ad6ccf09d1622bd960b14855ee11279a8a1eb0fb8247a4
3381             test11.iced               38c7eff6ad198bf51331692027b99b22f136996c986c6af1821b35fb92dbfc7b
815              test2.iced                1878ef98dfd141d3829b1d1cd6a630dc4d6f63a62d50fd34fbc6076aae16d1c7
1012             test3.iced                0fe215c969245808e5b08e95d3004a4fc660f4a90265557a3eeff30bccbfd244
1741             test4.iced                08c6f4f61f0f27c874d94932e68925546754d965c0800430d8578fbee5700e58
829              test5.iced                44b732d038147be5463005364c4363652455967e77065572f587de4541f93940
1236             test6.iced                ab545726a4dc9563ca2fa964e0c6a2a39a7cf5b1a60699fc51e45ae9e073061c
1890             test7.iced                60de18abe975f20eb4fef822e7519428d11e39003ea8d3aee6982a1d5729eb95
1442             test8.iced                14ee0da94ab37a8f6601ed5c6eea7ef683806727cdc7d6bd3255d4b150dee6f6
1459             test9.iced                f76339fe7093b4b605d52c00ecc9c3e7f259f9109841efe6d63d1eb3e020ad0f
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
git      # ignore .git and anything as described by .gitignore files
dropbox  # ignore .dropbox-cache and other Dropbox-related files    
kb       # ignore anything as described by .kbignore files          
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing