require('iced-coffee-script').register();
var main = require('./jenky_server_main').main;
main()
