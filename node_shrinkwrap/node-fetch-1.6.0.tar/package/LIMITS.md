
Known differences
=================

*As of 1.x release*

- Topics such as cross-origin, content security policy, mixed content, service workers are ignored, given our server-side context.

- Url input must be an absolute url, using either `http` or `https` as scheme.

- On the upside, there are no forbidden headers, and `res.url` contains the final url when following redirects.

- For convenience, `res.body` is a transform stream, so decoding can be handled independently.

- Similarly, `req.body` can either be a string, a buffer or a readable stream.

- Also, you can handle rejected fetch requests through checking `err.type` and `err.code`.

- Only support `res.text()`, `res.json()`, `res.buffer()` at the moment, until there are good use-cases for blob/arrayBuffer.

- There is currently no built-in caching, as server-side caching varies by use-cases.
