Everything on [Releases](https://github.com/fcomb/redux-logger/releases) page.
