iced-lock [![Build Status](https://travis-ci.org/maxtaco/iced-lock.svg?branch=maxtaco%2FCORE-3216)](https://travis-ci.org/maxtaco/iced-lock)
=========

Simple lock class
