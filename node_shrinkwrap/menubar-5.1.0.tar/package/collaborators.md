## Collaborators

menubar is only possible due to the excellent work of the following collaborators:

<table><tbody><tr><th align="left">maxogden</th><td><a href="https://github.com/maxogden">GitHub/maxogden</a></td></tr>
<tr><th align="left">fritzy</th><td><a href="https://github.com/fritzy">GitHub/fritzy</a></td></tr>
<tr><th align="left">pquerna</th><td><a href="https://github.com/pquerna">GitHub/pquerna</a></td></tr>
<tr><th align="left">fabien-d</th><td><a href="https://github.com/fabien-d">GitHub/fabien-d</a></td></tr>
<tr><th align="left">jenslind</th><td><a href="https://github.com/jenslind">GitHub/jenslind</a></td></tr>
</tbody></table>
