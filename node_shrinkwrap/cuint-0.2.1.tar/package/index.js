exports.UINT32 = require('./lib/uint32')
exports.UINT64 = require('./lib/uint64')