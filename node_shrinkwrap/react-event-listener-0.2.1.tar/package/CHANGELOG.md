All notable changes are described on the [Releases](https://github.com/oliviertassinari/react-swipeable-views/releases) page.
