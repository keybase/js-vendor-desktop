##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Comment: GPGTools - https://gpgtools.org

iQIcBAABCgAGBQJV57YyAAoJEGBSsq0xpmMc+KIP/RbPLqIt0k/b8kRDoAY1UJ7J
v5O/fNMv0MDeXD9IVHoHgCI7c8TrBXMXPXBnpjHw+LsBrZYo/nWOgvS4Zl/I5XiF
7rvdZfW9T3If2P5JGhMVIu/iP7r5uvWshee1Pidb6HGhCD6bjJ1lPx0GiIHwveiZ
D3a7LDapj0LNMvRAWJRQAS8tGFlVpCbzOGVFbI+mswQQWstTCqe9q4qb0/6IJ9sT
ztWQ2Uov/smM3Djldmsm7RmV2mvHhQPjBBQl/SczPA4Q/lcAFNIFNpGOa8aTLNYq
/5MBe0dQDrvi5pXClpgEjjhv63JA4zVdpOe7u/3MNFTgk2bG6lK6IKG3yrC6YNHG
SgqFzRinCNtIe6/6MRl9NJi8UNr0pTe8usP0FMMaUD79KJd+RvsvA4WYO6lzjgsF
yYqDW5ijZZ+rEqhJyWXeOgSJNFDVRjgC1Y4u0odGQ4Qcq6EO5h83VmxeuSl/vabD
X5jVAHlZrGQ9EDOttFny5ayDRlNE079kOQC9ViDW9WI8lQbKi2yPxaZNeBzMC0I8
UTpkNB8vOvZc2KRDLYgTxF+S0OZ3rRdphizRxjVWhUtGdIa6CJHicA/VG0dwvxKu
X0/3KwIaOs0WkXHd/yqkUkvYEhpij2BgO0s1ZkHvw1JViKHwMa/FaS1AR3XhPwxo
nlv2moqZDRPjnJpkVXkR
=ht3O
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size   exec  file                 contents                                                        
             ./                                                                                   
140            .gitignore         33573b523e3d969c68baef03100ce1e6e07d69735443d39b41bc7504df6dcf5f
38             .travis.yml        e36b9b52fccb8114b8b8b13bdfbaa87342b07bda069b517ca34db9f85adaa3e3
360            CHANGELOG.md       5640ed57b9f06092c9436d9a6aa057cdb33378bdc6771dba1d300f744615aa9f
907            Makefile           4339d43218088c5087fdc43c5b8dcb50112e067484bc7ba6faee959dd9e5258c
1753           README.md          0c5c44d85d1e2e945168b611499ef28346f0ee79792e26c4d4e9c4ce9ba5b08c
               bench/                                                                             
5796             b1.iced          e859dc828b63636029d9d9746daf5718f9955067961da21be8942ccafd14369e
1571             b2.iced          9a7e5d507b4984e2a26618299d1d1139adc5c2a6e463f41ab594992747e04511
473              b3.iced          15379e38aa61508c66522533a2dab3653b56601860e9c5fb37627ef4bc5ef0dd
481              b4.iced          c22c31716a4a41b7148cad36d591ffd933665c1b582f0a7eba0f0c0dd5e4fdae
542              b5.iced          05df340ead6f3fafa5f84ba726a9624e3b777142bde53180a357609a83b63758
77               rj.iced          54863e02ee6217bb993bc0330b650e5d439037287b5d722f01a94f223c8804bf
               lib/                                                                               
7130             buffer.js        2d2b1b128ff5e684efb6f544aa3f2020aa2c52d6d6020b4b762f34bdca2a6bf1
1087             const.js         7e33560fdd533e1a5b1265ff92ab56791c397ab77ddf93e9b6fac97b7babc64c
1422             frame.js         a6d864495f50b789bf026da6e4fd200cfb6987425d7b23e74b9a218f2c1e05b6
249              main.js          58dd1a533963c6d028fddd236fffa2c0501bbb6f02bfe8417ef4779392cab30f
7168             pack.js          0debe2cf6068190b1cfe298e56b6995c0d738e8eb69fae5290cad4f35b98a402
7164             unpack.js        a52fa93cd013a4278dbdd918ecf08c115f124068be66f7f0290307ed949a75cc
614              util.js          d93102f28abc76bc2f566e31a943c1576c11f5a68c896cbe5a8556680c222e02
3631           package.json       cd6cf6e3f6aa64f2a83ec1fe62a478d69a273e07c5b239a23c9b8caed2a90b4f
               src/                                                                               
4998             buffer.coffee    dc9d95b44d5b38bbfa0ff0378fc8dccf2e8f52ea73b628b97be16f7b7739a235
1402             const.coffee     5b5274ad7699100545af000185ff87ddd68d0c01f760f74761c7bd8c2082fbc5
1150             frame.coffee     b9863479dba55d66e503bcd695c0ba56db8fb17dcf8038ee3b04da5b75f0a6b2
163              main.coffee      7dae14869051c9486789a2cf29052ea00c8d425e3e30f9e75da9b350ca54b863
6981             pack.coffee      6348f0d6d0abceaf7e46c5f9deec91423a2c608ce59e70339877852d699ab6ee
5493             unpack.coffee    99a4e92046ea25b23fbc14ccb52918cf71ee1f7ccdb0b2b8263dea2b873791a9
549              util.coffee      67b576dafba2fe8be7075fa11226fc98b1a49fb221c1ac892a39994259d0d084
               test/                                                                              
                 browser/                                                                         
31                 howto          e2951ae73baa3c65e30a82e8e07d23d8c72d85ddd1edf594e2c242e8e35adcdd
285                index.html     f32649555f86cc6c56e7028e70835ea7594cb2545d55f4001525aa8e95a8d25f
359                main.iced      f15d562659c39441dd76e16a6936f5d559fc0dfd416a4b9b2595314564a79db4
309                zombie.iced    32fbbcf672e6047615528dc468e629d0a55d8c62341032dd946099e78a2e5810
                 files/                                                                           
4504               checks.iced    4bbe928a3bbaeb04f507fc129453fcb1d8970738da4c721380d66d6c67f86025
1409               frame.iced     782b4cdf066a4cb054e972ca6e1d06fa00ad6a1d13721c8df20b3e146e90dae9
865                pack.iced      3636709b983cdafabc07f99469e462dd7032da226a9a6d095b64b27f3a0758cc
403                sort.iced      623c2de5c466a5186f66fcf2a0352793862a3b97785ec7b237c79ec52aae5816
4173               unpack.iced    16e39758f0791c94fc30b1881f42c4fb493d4fd90b07921cbb3b04b7a49f0e1b
383                utf8.iced      b23e30094ea5119ee0b9631231759efd3630d009af0defca4e006e6d893581d1
                 pack/                                                                            
46595              data.js        38a41df93dcfedb37993ccb181a54bd0e5fa629a1f4357c527982cabf699e200
277                generate.iced  d42ade70bfe073e9b3f4016b6bb4421469f71a3415bb36ac48abd947f9af4e63
1531               input.iced     278dcf9bffacc7c9c775bd1ce102030d5bdd3dd5486b438c160d4ff2e4b7c55c
169              run.iced         70ef38fc04a9ee264e2317e5b4dcb00a69a996139e98b5d9e34d0ffa16609479
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
git      # ignore .git and anything as described by .gitignore files
dropbox  # ignore .dropbox-cache and other Dropbox-related files    
kb       # ignore anything as described by .kbignore files          
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing