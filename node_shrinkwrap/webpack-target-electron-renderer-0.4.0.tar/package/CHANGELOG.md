# 0.1.1 (2015/10/20)

#### Bugs Fixed

- **web-view -> web-frame:** [#1](https://github.com/chentsulin/webpack-target-electron-renderer/pull/1)
