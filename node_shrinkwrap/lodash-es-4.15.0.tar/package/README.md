# lodash-es v4.15.0

The [Lodash](https://lodash.com/) library exported as [ES](http://www.ecma-international.org/ecma-262/6.0/) modules.

Generated using [lodash-cli](https://www.npmjs.com/package/lodash-cli):
```bash
$ lodash modularize exports=es -o ./
```

See the [package source](https://github.com/lodash/lodash/tree/4.15.0-es) for more details.
