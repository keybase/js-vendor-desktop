import Hash from './_Hash.js';
import ListCache from './_ListCache.js';
import Map from './_Map.js';

/**
 * Removes all key-value entries from the map.
 *
 * @private
 * @name clear
 * @memberOf MapCache
 */
function mapCacheClear() {
  this.__data__ = {
    'hash': new Hash,
    'map': new (Map || ListCache),
    'string': new Hash
  };
}

export default mapCacheClear;
