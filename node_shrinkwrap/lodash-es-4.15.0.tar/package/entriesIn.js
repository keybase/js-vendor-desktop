export { default } from './toPairsIn.js'
