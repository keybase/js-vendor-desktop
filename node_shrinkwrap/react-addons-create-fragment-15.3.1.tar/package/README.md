# react-addons-create-fragment

This package provides the React createFragment add-on.

See <https://facebook.github.io/react/docs/create-fragment.html> for more information.