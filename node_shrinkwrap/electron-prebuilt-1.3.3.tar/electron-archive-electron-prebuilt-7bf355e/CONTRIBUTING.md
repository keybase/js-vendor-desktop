releases for this module are handled by https://github.com/johnmuhl/electron-prebuilt-updater

versions published to npm should match the versions published to [github releases for electron](https://github.com/electron/electron/releases)

coding style should be `standard`:

[![js-standard-style](https://raw.githubusercontent.com/feross/standard/master/badge.png)](https://github.com/feross/standard)
