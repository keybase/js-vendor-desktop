# ansi-viewer

A terminal app to view ANSI art from http://artscene.textfiles.com/ansi/.

![ansi-viewer](https://raw.githubusercontent.com/chjj/blessed/master/img/ansi-viewer.png)

## Contribution and License Agreement

If you contribute code to this project, you are implicitly allowing your code
to be distributed under the MIT license. You are also implicitly verifying that
all code is your original work. `</legalese>`

## License

Copyright (c) 2015, Christopher Jeffrey. (MIT License)

See LICENSE for more info.
