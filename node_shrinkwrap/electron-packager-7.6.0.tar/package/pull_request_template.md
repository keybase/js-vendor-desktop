**Have you read the [section in CONTRIBUTING.md about pull requests](https://github.com/electron-userland/electron-packager/blob/master/CONTRIBUTING.md#filing-pull-requests)?**



**Summarize your changes:**



**Are your changes appropriately documented?**



**Do your changes have sufficient test coverage?**



**Does the testsuite pass successfully on your local machine?**


