var common = module.exports;

common.DelayedStream = require('..');
common.assert = require('assert');
common.fake = require('fake');
common.PORT = 49252;
