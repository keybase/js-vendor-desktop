# react-addons-transition-group

This package provides the React TransitionGroup add-on.

See <https://facebook.github.io/react/docs/animation.html> for more information.