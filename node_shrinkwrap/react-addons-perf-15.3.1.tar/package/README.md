# react-addons-perf

This package provides the React Perf add-on.

See <https://facebook.github.io/react/docs/perf.html> for more information.