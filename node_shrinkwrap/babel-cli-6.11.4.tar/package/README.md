# babel-cli

> Babel command line.

## Install

```sh
$ npm install babel-cli
```

## Usage 

```sh
$ babel script.js
```

For more in depth documentation see: http://babeljs.io/docs/usage/cli/
