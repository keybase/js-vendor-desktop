module.exports = require('./lib/static/prefixAll')
